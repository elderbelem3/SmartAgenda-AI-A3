import { createServerFn } from "@tanstack/react-start";
import { generateObject } from "ai";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const EventInput = z.object({
  title: z.string().min(1).max(200),
  description: z.string().max(2000).optional().nullable(),
  event_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  event_time: z.string().regex(/^\d{2}:\d{2}(:\d{2})?$/).optional().nullable(),
});

export const listEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("events")
      .select("*")
      .order("event_date", { ascending: true })
      .order("event_time", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => EventInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("events")
      .insert({ ...data, user_id: context.userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    EventInput.extend({ id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { id, ...patch } = data;
    const { data: row, error } = await context.supabase
      .from("events")
      .update(patch)
      .eq("id", id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("events").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const WEEKDAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"] as const;
type Weekday = typeof WEEKDAYS[number];

function expandWeekly(weekdays: Weekday[], startISO: string, weeks: number): string[] {
  const start = new Date(startISO + "T00:00:00");
  const targets = new Set(weekdays.map((w) => WEEKDAYS.indexOf(w)));
  const out: string[] = [];
  for (let i = 0; i < weeks * 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    if (targets.has(d.getDay())) out.push(d.toISOString().slice(0, 10));
  }
  return out;
}

export const parseAndCreateEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ text: z.string().min(1).max(2000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const weekdayName = WEEKDAYS[now.getDay()];
    const gateway = createLovableAiGatewayProvider(key);

    const { object: parsed } = await generateObject({
      model: gateway("openai/gpt-5"),
      system: `Você é um assistente de agenda inteligente que conversa em português do Brasil e extrai compromissos em JSON.
Hoje é ${today} (${weekdayName}).

Sua tarefa: INTERPRETAR a mensagem do usuário (mesmo que seja uma frase longa, informal ou conversacional) e extrair TODOS os compromissos mencionados. Retorne um array "events" — pode ter 0, 1 ou vários itens.

Entenda variações naturais como:
- "tenho", "preciso ir", "vou ter", "marquei", "agendei", "lembra que tem", "todo dia", "toda semana", "sempre"
- horários: "às 19h", "19 horas", "7 da noite", "meio-dia", "às 14:30", "de manhã" (use 09:00), "à tarde" (14:00), "à noite" (20:00)
- datas: "hoje", "amanhã", "depois de amanhã", "segunda que vem", "dia 15", "próxima sexta"
- recorrência: "toda quinta", "todas as segundas e quartas", "semanalmente", "todo dia útil"

Para cada compromisso preencha:
- title: nome curto do compromisso (ex: "Academia", "Consulta médica", "Reunião com Maria")
- description: detalhes extras mencionados ou string vazia
- time: HH:MM em 24h, ou string vazia se não houver horário
- recurrence: "weekly" se repetir semanalmente, senão "once"
- date: para "once", data YYYY-MM-DD resolvida a partir de hoje. Para "weekly", string vazia
- weekdays: para "weekly", dias em inglês minúsculo (sunday..saturday). Para "once", lista vazia
- weeks_to_repeat: para "weekly" use 8 por padrão. Para "once" use 0

Exemplos:
"Consulta médica amanhã às 14h" → 1 evento once
"Tenho academia toda quinta e sexta às 19 horas" → 1 evento weekly, weekdays=[thursday,friday]
"Lembra que segunda tenho reunião 10h e na terça vou no dentista às 15h" → 2 eventos once
"Vou começar inglês toda terça e quinta de manhã, umas 8h, e também tenho terapia toda sexta às 18h" → 2 eventos weekly
"Marquei jantar com a Ana sábado que vem às 20h no restaurante japonês" → 1 evento once com description mencionando o restaurante`,
      prompt: data.text,
      schema: z.object({
        events: z.array(
          z.object({
            title: z.string(),
            description: z.string(),
            time: z.string(),
            recurrence: z.enum(["once", "weekly"]),
            date: z.string(),
            weekdays: z.array(z.enum(WEEKDAYS)),
            weeks_to_repeat: z.number(),
          }),
        ),
      }),
    });

    const rows: Array<z.infer<typeof EventInput>> = [];
    for (const ev of parsed.events) {
      const time = ev.time && /^\d{1,2}:\d{2}/.test(ev.time)
        ? ev.time.padStart(5, "0").slice(0, 5)
        : null;
      const description = ev.description?.trim() || null;

      if (ev.recurrence === "weekly" && ev.weekdays.length > 0) {
        const weeks = Math.min(Math.max(ev.weeks_to_repeat || 8, 1), 12);
        const dates = expandWeekly(ev.weekdays, today, weeks);
        for (const d of dates) {
          rows.push(EventInput.parse({ title: ev.title, description, event_date: d, event_time: time }));
        }
      } else if (ev.date && /^\d{4}-\d{2}-\d{2}$/.test(ev.date)) {
        rows.push(EventInput.parse({ title: ev.title, description, event_date: ev.date, event_time: time }));
      }
    }

    if (rows.length === 0) throw new Error("Nenhum compromisso identificado");

    const { data: inserted, error } = await context.supabase
      .from("events")
      .insert(rows.map((r) => ({ ...r, user_id: context.userId })))
      .select();
    if (error) throw new Error(error.message);

    // Build a friendly summary grouped by title
    const grouped = new Map<string, typeof inserted>();
    for (const row of inserted ?? []) {
      const arr = grouped.get(row.title) ?? [];
      arr.push(row);
      grouped.set(row.title, arr);
    }
    const summary = Array.from(grouped.entries()).map(([title, items]) => ({
      title,
      count: items.length,
      first_date: items[0].event_date,
      time: items[0].event_time,
    }));

    return { created: inserted ?? [], summary };
  });
