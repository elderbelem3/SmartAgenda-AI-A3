import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useRef, useEffect } from "react";
import {
  format, startOfMonth, endOfMonth, startOfWeek, endOfWeek,
  addDays, addMonths, subMonths, isSameMonth, isSameDay, parseISO,
} from "date-fns";
import { ptBR } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Plus, Send, Trash2, Pencil, LogOut, Sparkles, Loader2, Check, X } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { supabase } from "@/integrations/supabase/client";
import { listEvents, createEvent, updateEvent, deleteEvent, parseMessage, executeActions } from "@/lib/events.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/_authenticated/app")({
  component: AppPage,
});

type EventRow = {
  id: string;
  title: string;
  description: string | null;
  event_date: string;
  event_time: string | null;
  event_end_time: string | null;
};

type Summary = { title: string; count: number; first_date: string; last_date: string; time: string | null; end_time: string | null };

type Conflict = {
  date: string;
  proposed: { title: string; time: string | null; end_time: string | null };
  existing: EventRow;
};

type ChatMsg = {
  role: "user" | "assistant";
  content: string;
  pendingActions?: unknown[];
  queryResults?: EventRow[];
  conflicts?: Conflict[];
};

function AppPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const list = useServerFn(listEvents);
  const create = useServerFn(createEvent);
  const update = useServerFn(updateEvent);
  const remove = useServerFn(deleteEvent);
  const parse = useServerFn(parseMessage);
  const execute = useServerFn(executeActions);

  const { data: events = [] } = useQuery({
    queryKey: ["events"],
    queryFn: () => list() as Promise<EventRow[]>,
  });

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [editingEvent, setEditingEvent] = useState<EventRow | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const invalidate = () => qc.invalidateQueries({ queryKey: ["events"] });

  const createMut = useMutation({
    mutationFn: (data: Omit<EventRow, "id">) => create({ data }),
    onSuccess: () => { invalidate(); toast.success("Compromisso criado"); setDialogOpen(false); },
    onError: (e: Error) => toast.error(e.message),
  });
  const updateMut = useMutation({
    mutationFn: (data: EventRow) => update({ data }),
    onSuccess: () => { invalidate(); toast.success("Compromisso atualizado"); setDialogOpen(false); },
    onError: (e: Error) => toast.error(e.message),
  });
  const deleteMut = useMutation({
    mutationFn: (id: string) => remove({ data: { id } }),
    onSuccess: () => { invalidate(); toast.success("Compromisso excluído"); },
    onError: (e: Error) => toast.error(e.message),
  });

  // Chat
  const [messages, setMessages] = useState<ChatMsg[]>([
    { role: "assistant", content: "Olá! Sou a **SmartAgenda**. Posso entender frases como:\n\n- *\"Tenho aula toda semana das 19h às 22h de segunda a sexta menos terça até o final do ano\"*\n- *\"Tenho dentista amanhã\"*\n- *\"Toda segunda e quarta às 19h reunião\"*\n- *\"Último sábado do mês tenho clube\"*\n- *\"O que tenho esta semana?\"*\n- *\"Adia minha reunião de amanhã para sexta às 14h\"*" },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const chatEnd = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, sending]);
  useEffect(() => { inputRef.current?.focus(); }, [sending]);

  function formatSummary(s: Summary): string {
    const dateStr = format(parseISO(s.first_date), "dd/MM", { locale: ptBR });
    const timeStr = s.time ? ` ${s.time.slice(0, 5)}${s.end_time ? `–${s.end_time.slice(0, 5)}` : ""}` : "";
    if (s.count > 1) {
      const lastStr = format(parseISO(s.last_date), "dd/MM", { locale: ptBR });
      return `**${s.title}** —${timeStr} (${s.count} ocorrências, ${dateStr} → ${lastStr})`;
    }
    return `**${s.title}** em ${dateStr}${timeStr}`;
  }

  function renderResponse(res: any): ChatMsg {
    // A mensagem amigável já vem montada do backend. Apenas anexamos resumo
    // executado (quando há) e padrões usados se ainda não estiverem na mensagem.
    const parts: string[] = [];
    if (res.message) parts.push(res.message);

    if (res.summary?.deleted?.length) {
      parts.push("\n**🗑 Removidos:**");
      for (const s of res.summary.deleted) parts.push(`- ${formatSummary(s)}`);
    }
    if (res.summary?.created?.length) {
      parts.push("\n**✓ Adicionados:**");
      for (const s of res.summary.created) parts.push(`- ${formatSummary(s)}`);
    }

    const msg: ChatMsg = { role: "assistant", content: parts.join("\n") || "Pronto." };
    if (res.needs_confirmation && res.pending_actions?.length) {
      msg.pendingActions = res.pending_actions;
    }
    if (res.conflicts?.length) {
      msg.conflicts = res.conflicts;
    }
    if (res.query_results?.length) {
      msg.queryResults = res.query_results;
    }
    return msg;
  }

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    setMessages((m) => [...m, { role: "user", content: text }]);
    setInput("");
    setSending(true);
    try {
      const res = (await parse({ data: { text } })) as any;
      setMessages((m) => [...m, renderResponse(res)]);
      if (res.executed) invalidate();
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", content: "Tive um problema. Pode tentar reformular?" }]);
      toast.error((err as Error).message);
    } finally {
      setSending(false);
    }
  }

  async function handleConfirm(idx: number, actions: unknown[]) {
    setMessages((m) => m.map((msg, i) => (i === idx ? { ...msg, pendingActions: undefined } : msg)));
    try {
      const res = (await execute({ data: { actions: actions as any } })) as any;
      setMessages((m) => [...m, renderResponse({ ...res, message: "Confirmado." })]);
      invalidate();
    } catch (err) {
      toast.error((err as Error).message);
      setMessages((m) => [...m, { role: "assistant", content: "Não consegui executar." }]);
    }
  }

  function handleCancel(idx: number) {
    setMessages((m) => {
      const updated = m.map((msg, i) => (i === idx ? { ...msg, pendingActions: undefined } : msg));
      return [...updated, { role: "assistant", content: "Ok, cancelei." }];
    });
  }

  async function handleLogout() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  // Calendar grid
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const gridEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const days: Date[] = [];
  for (let d = gridStart; d <= gridEnd; d = addDays(d, 1)) days.push(d);

  const eventsByDay = events.reduce<Record<string, EventRow[]>>((acc, ev) => {
    (acc[ev.event_date] ??= []).push(ev);
    return acc;
  }, {});

  const dayEvents = selectedDate ? eventsByDay[format(selectedDate, "yyyy-MM-dd")] ?? [] : [];

  function openCreate(date?: Date) {
    setEditingEvent({
      id: "",
      title: "",
      description: "",
      event_date: format(date ?? selectedDate ?? new Date(), "yyyy-MM-dd"),
      event_time: null,
      event_end_time: null,
    });
    setDialogOpen(true);
  }

  function openEdit(ev: EventRow) {
    setEditingEvent(ev);
    setDialogOpen(true);
  }

  function handleSaveEvent(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editingEvent) return;
    const fd = new FormData(e.currentTarget);
    const payload = {
      title: String(fd.get("title") || "").trim(),
      description: String(fd.get("description") || "").trim() || null,
      event_date: String(fd.get("event_date") || ""),
      event_time: (String(fd.get("event_time") || "").trim() || null) as string | null,
      event_end_time: (String(fd.get("event_end_time") || "").trim() || null) as string | null,
    };
    if (editingEvent.id) {
      updateMut.mutate({ id: editingEvent.id, ...payload });
    } else {
      createMut.mutate(payload);
    }
  }

  function timeLabel(ev: EventRow) {
    if (!ev.event_time) return "";
    const t = ev.event_time.slice(0, 5);
    return ev.event_end_time ? `${t}–${ev.event_end_time.slice(0, 5)}` : t;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={logo} alt="" className="h-8 w-8" width={32} height={32} />
            <span className="font-semibold">SmartAgenda <span className="text-primary">AI</span></span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" /> Sair
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 py-6 grid lg:grid-cols-[1fr_400px] gap-6">
        {/* Calendar */}
        <section className="rounded-2xl border border-border bg-card p-4 sm:p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold capitalize">
                {format(currentMonth, "MMMM yyyy", { locale: ptBR })}
              </h1>
              <p className="text-sm text-muted-foreground">{events.length} compromissos</p>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => { setCurrentMonth(new Date()); setSelectedDate(new Date()); }}>
                Hoje
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button size="sm" className="ml-2" onClick={() => openCreate()}>
                <Plus className="h-4 w-4 mr-1" /> Novo
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-2">
            {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((d) => (
              <div key={d} className="text-xs font-medium text-muted-foreground text-center py-2">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {days.map((day) => {
              const key = format(day, "yyyy-MM-dd");
              const inMonth = isSameMonth(day, currentMonth);
              const isToday = isSameDay(day, new Date());
              const isSelected = selectedDate && isSameDay(day, selectedDate);
              const dayEvs = eventsByDay[key] ?? [];
              return (
                <button
                  key={key}
                  onClick={() => setSelectedDate(day)}
                  className={`min-h-[80px] sm:min-h-[100px] rounded-lg p-2 text-left transition-all border ${
                    isSelected ? "border-primary bg-primary/10" : "border-transparent hover:border-border hover:bg-accent/40"
                  } ${!inMonth ? "opacity-40" : ""}`}
                >
                  <div className={`text-sm font-medium inline-flex items-center justify-center w-6 h-6 rounded-full ${
                    isToday ? "bg-primary text-primary-foreground" : ""
                  }`}>{format(day, "d")}</div>
                  <div className="mt-1 space-y-1">
                    {dayEvs.slice(0, 2).map((ev) => (
                      <div key={ev.id} className="text-[10px] sm:text-xs truncate rounded bg-primary/20 text-primary-foreground px-1 py-0.5">
                        <span className="text-primary-glow font-medium">{ev.event_time?.slice(0, 5) ?? ""}</span> {ev.title}
                      </div>
                    ))}
                    {dayEvs.length > 2 && (
                      <div className="text-[10px] text-muted-foreground">+{dayEvs.length - 2} mais</div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {selectedDate && (
            <div className="mt-6 pt-6 border-t border-border">
              <h2 className="font-semibold mb-3">
                {format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}
              </h2>
              {dayEvents.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum compromisso. <button className="text-primary hover:underline" onClick={() => openCreate()}>Criar um?</button></p>
              ) : (
                <ul className="space-y-2">
                  {dayEvents.map((ev) => (
                    <li key={ev.id} className="flex items-start gap-3 rounded-lg border border-border bg-background/50 p-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          {ev.event_time && <span className="text-xs font-mono text-primary">{timeLabel(ev)}</span>}
                          <h3 className="font-medium truncate">{ev.title}</h3>
                        </div>
                        {ev.description && <p className="text-sm text-muted-foreground mt-1">{ev.description}</p>}
                      </div>
                      <Button size="icon" variant="ghost" onClick={() => openEdit(ev)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMut.mutate(ev.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </section>

        {/* Chat */}
        <aside className="rounded-2xl border border-border bg-card flex flex-col h-[calc(100vh-7rem)] sticky top-20">
          <div className="border-b border-border p-4 flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: "var(--gradient-primary)" }}>
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h2 className="font-semibold text-sm">Assistente IA</h2>
              <p className="text-xs text-muted-foreground">Linguagem natural avançada</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[90%] rounded-2xl px-4 py-2 text-sm ${
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground"
                }`}>
                  <div className="prose prose-sm prose-invert max-w-none [&_p]:my-1 [&_ul]:my-1 [&_li]:my-0">
                    <ReactMarkdown>{m.content}</ReactMarkdown>
                  </div>

                  {m.queryResults && m.queryResults.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {Object.entries(
                        m.queryResults.reduce<Record<string, EventRow[]>>((acc, ev) => {
                          (acc[ev.event_date] ??= []).push(ev);
                          return acc;
                        }, {}),
                      ).slice(0, 14).map(([date, evs]) => (
                        <div key={date} className="rounded-lg bg-background/40 border border-border/50 p-2">
                          <div className="text-[11px] font-semibold text-primary uppercase tracking-wide mb-1">
                            {format(parseISO(date), "EEE, dd 'de' MMM", { locale: ptBR })}
                          </div>
                          <ul className="space-y-1">
                            {evs.map((ev) => (
                              <li key={ev.id} className="flex gap-2 text-xs">
                                <span className="font-mono text-primary-glow min-w-[80px]">
                                  {ev.event_time ? timeLabel(ev) : "—"}
                                </span>
                                <span className="flex-1">{ev.title}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                      {m.queryResults.length > 20 && (
                        <div className="text-[11px] text-muted-foreground">…e mais resultados</div>
                      )}
                    </div>
                  )}

                  {m.pendingActions && (
                    <div className="mt-3 flex gap-2 flex-wrap">
                      <Button size="sm" onClick={() => handleConfirm(i, m.pendingActions!)}>
                        <Check className="h-3 w-3 mr-1" />
                        {m.conflicts && m.conflicts.length > 0 ? "Criar mesmo assim" : "Confirmar"}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleCancel(i)}>
                        <X className="h-3 w-3 mr-1" /> Cancelar
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {sending && (
              <div className="flex justify-start">
                <div className="rounded-2xl px-4 py-2 text-sm bg-secondary text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-3 w-3 animate-spin" /> Analisando...
                </div>
              </div>
            )}
            <div ref={chatEnd} />
          </div>

          <form onSubmit={handleSend} className="border-t border-border p-3 flex gap-2">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder='Ex: "Reunião amanhã 15h" ou "O que tenho na sexta?"'
              disabled={sending}
              autoFocus
            />
            <Button type="submit" size="icon" disabled={sending || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </aside>
      </main>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingEvent?.id ? "Editar compromisso" : "Novo compromisso"}</DialogTitle>
          </DialogHeader>
          {editingEvent && (
            <form onSubmit={handleSaveEvent} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título</Label>
                <Input id="title" name="title" required defaultValue={editingEvent.title} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="event_date">Data</Label>
                  <Input id="event_date" name="event_date" type="date" required defaultValue={editingEvent.event_date} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event_time">Início</Label>
                  <Input id="event_time" name="event_time" type="time" defaultValue={editingEvent.event_time ?? ""} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event_end_time">Fim</Label>
                  <Input id="event_end_time" name="event_end_time" type="time" defaultValue={editingEvent.event_end_time ?? ""} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea id="description" name="description" rows={3} defaultValue={editingEvent.description ?? ""} />
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={createMut.isPending || updateMut.isPending}>
                  {createMut.isPending || updateMut.isPending ? "Salvando..." : "Salvar"}
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
