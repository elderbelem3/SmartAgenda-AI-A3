import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar – SmartAgenda AI" },
      { name: "description", content: "Acesse ou crie sua conta no SmartAgenda AI." },
    ],
  }),
  component: AuthPage,
});

function nameToEmail(name: string) {
  const slug = name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ".")
    .replace(/^\.+|\.+$/g, "");
  return `${slug}@smartagenda.local`;
}

function AuthPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/app" });
    });
  }, [navigate]);

  function validateName(n: string) {
    const slug = n.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9 ]+/g, "");
    return slug.length >= 2;
  }

  async function handleSignIn(e: React.FormEvent) {
    e.preventDefault();
    if (!validateName(name)) return toast.error("Informe um nome válido");
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: nameToEmail(name),
      password,
    });
    setLoading(false);
    if (error) return toast.error("Nome ou senha incorretos");
    toast.success("Bem-vindo de volta!");
    navigate({ to: "/app" });
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault();
    if (!validateName(name)) return toast.error("Informe um nome válido");
    setLoading(true);
    const email = nameToEmail(name);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/app`,
        data: { display_name: name.trim() },
      },
    });
    if (error) {
      setLoading(false);
      return toast.error(error.message.includes("registered") ? "Esse nome já está em uso" : error.message);
    }
    // Auto sign-in (auto-confirm está ativo)
    const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (signInErr) return toast.error(signInErr.message);
    toast.success("Conta criada!");
    navigate({ to: "/app" });
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative" style={{ background: "var(--gradient-hero), var(--color-background)" }}>
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center gap-2 justify-center mb-8">
          <img src={logo} alt="" className="h-10 w-10" width={40} height={40} />
          <span className="font-semibold text-xl">SmartAgenda <span className="text-primary">AI</span></span>
        </Link>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-2xl">
          <Tabs defaultValue="signin">
            <TabsList className="grid grid-cols-2 w-full mb-6">
              <TabsTrigger value="signin">Entrar</TabsTrigger>
              <TabsTrigger value="signup">Cadastrar</TabsTrigger>
            </TabsList>

            <TabsContent value="signin">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name-in">Nome</Label>
                  <Input id="name-in" type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="seu nome" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pwd-in">Senha</Label>
                  <Input id="pwd-in" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Entrando..." : "Entrar"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignUp} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name-up">Nome</Label>
                  <Input id="name-up" type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="como devemos te chamar" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pwd-up">Senha</Label>
                  <Input id="pwd-up" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Criando..." : "Criar conta"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
