import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Calendar, Sparkles, MessageSquare } from "lucide-react";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SmartAgenda AI – Agenda inteligente com IA" },
      { name: "description", content: "Crie compromissos em linguagem natural. A IA extrai título, data, horário e descrição automaticamente." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
      <header className="relative z-10 mx-auto max-w-6xl px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img src={logo} alt="SmartAgenda AI" className="h-9 w-9" width={36} height={36} />
          <span className="font-semibold text-lg">SmartAgenda <span className="text-primary">AI</span></span>
        </div>
        <Link to="/auth">
          <Button variant="ghost">Entrar</Button>
        </Link>
      </header>

      <main className="relative z-10 mx-auto max-w-4xl px-6 pt-16 pb-24 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-3 py-1 text-xs text-muted-foreground mb-6">
          <Sparkles className="h-3 w-3 text-primary" />
          Sua agenda powered by IA
        </div>
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight">
          Compromissos em <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-primary)" }}>linguagem natural</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          Escreva "reunião com cliente amanhã às 15h sobre novo projeto" e o SmartAgenda AI cria seu compromisso automaticamente.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <Link to="/auth">
            <Button size="lg" className="text-base" style={{ boxShadow: "var(--shadow-glow)" }}>
              Começar grátis
            </Button>
          </Link>
        </div>

        <div className="mt-20 grid sm:grid-cols-3 gap-4 text-left">
          {[
            { icon: MessageSquare, t: "Chat com IA", d: "Converse e descreva seus compromissos como faria com um assistente." },
            { icon: Sparkles, t: "Extração automática", d: "A IA identifica título, data, horário e descrição em segundos." },
            { icon: Calendar, t: "Calendário mensal", d: "Visualize toda sua agenda em um calendário moderno e responsivo." },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="rounded-xl border border-border bg-card/50 p-5 backdrop-blur">
              <Icon className="h-5 w-5 text-primary" />
              <h3 className="mt-3 font-semibold">{t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
