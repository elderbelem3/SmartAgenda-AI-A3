import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const TIME_RE = /^\d{2}:\d{2}(:\d{2})?$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const EventInput = z.object({
  title: z.string().min(1).max(200),
  description: z.string().max(2000).optional().nullable(),
  event_date: z.string().regex(DATE_RE),
  event_time: z.string().regex(TIME_RE).optional().nullable(),
  event_end_time: z.string().regex(TIME_RE).optional().nullable(),
});

export const listEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("events")
      .select("*")
      .order("event_date", { ascending: true })
      .order("event_time", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => EventInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("events")
      .insert({ ...data, user_id: context.userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    EventInput.extend({ id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { id, ...patch } = data;
    const { data: row, error } = await context.supabase
      .from("events")
      .update(patch)
      .eq("id", id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("events").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ====== Helpers ======

const WEEKDAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"] as const;
type Weekday = typeof WEEKDAYS[number];

const WEEKDAY_PT_SHORT: Record<Weekday, string> = {
  sunday: "dom", monday: "seg", tuesday: "ter", wednesday: "qua",
  thursday: "qui", friday: "sex", saturday: "sáb",
};
const WEEKDAY_PT_LONG: Record<Weekday, string> = {
  sunday: "domingo", monday: "segunda", tuesday: "terça", wednesday: "quarta",
  thursday: "quinta", friday: "sexta", saturday: "sábado",
};

type EventRow = {
  id: string;
  title: string;
  description: string | null;
  event_date: string;
  event_time: string | null;
  event_end_time: string | null;
};

function normalize(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
}

function isoOf(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function normalizeTime(t?: string | null): string | null {
  if (!t || !/^\d{1,2}:\d{2}/.test(t)) return null;
  return t.padStart(5, "0").slice(0, 5);
}

function fmtDateBR(iso: string): string {
  if (!DATE_RE.test(iso)) return iso;
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function fmtTime(t?: string | null): string | null {
  return t ? t.slice(0, 5) : null;
}

const MAX_OCCURRENCES = 365;

const CreateAction = z.object({
  type: z.literal("create"),
  title: z.string().nullish(),
  description: z.string().nullish(),
  date: z.string().nullish(),
  time: z.string().nullish(),
  end_time: z.string().nullish(),
  recurrence: z.enum(["once", "daily", "weekly", "biweekly", "monthly", "monthly_by_weekday"]).nullish().catch("once"),
  weekdays: z.array(z.enum(WEEKDAYS)).nullish().catch([]),
  recurrence_until: z.string().nullish(),
  exceptions: z.array(z.enum(WEEKDAYS)).nullish().catch([]),
  month_position: z.enum(["first", "second", "third", "fourth", "last"]).nullish(),
});

const DeleteAction = z.object({
  type: z.literal("delete"),
  title_keyword: z.string().nullish(),
  date: z.string().nullish(),
  date_from: z.string().nullish(),
  date_to: z.string().nullish(),
});

const QueryAction = z.object({
  type: z.literal("query"),
  date: z.string().nullish(),
  date_from: z.string().nullish(),
  date_to: z.string().nullish(),
  title_keyword: z.string().nullish(),
});

const Action = z.union([CreateAction, DeleteAction, QueryAction]);
type Action = z.infer<typeof Action>;
type CreateAct = z.infer<typeof CreateAction>;

const ParseResult = z.object({
  intent: z.enum(["create", "delete", "reschedule", "query", "clarify"]).catch("clarify"),
  confidence: z.number().min(0).max(1).catch(0),
  reasoning: z.string().nullish(),
  clarification: z.string().nullish(),
  defaults_used: z.array(z.string()).nullish().catch([]),
  message: z.string().nullish(),
  actions: z.array(Action).nullish().catch([]),
});
type ParseResult = z.infer<typeof ParseResult>;

function nthWeekdayOfMonth(year: number, month: number, weekday: number, position: "first" | "second" | "third" | "fourth" | "last"): Date | null {
  if (position === "last") {
    const last = new Date(year, month + 1, 0);
    const diff = (last.getDay() - weekday + 7) % 7;
    return new Date(year, month, last.getDate() - diff);
  }
  const n = { first: 1, second: 2, third: 3, fourth: 4 }[position];
  const first = new Date(year, month, 1);
  const diff = (weekday - first.getDay() + 7) % 7;
  const day = 1 + diff + (n - 1) * 7;
  const d = new Date(year, month, day);
  return d.getMonth() === month ? d : null;
}

function expandRecurrence(act: CreateAct, today: string): string[] {
  const recurrence = act.recurrence ?? "once";
  const weekdays = (act.weekdays ?? []) as Weekday[];
  const exceptions = new Set(((act.exceptions ?? []) as Weekday[]).map((w) => WEEKDAYS.indexOf(w)));
  const startISO = act.date && DATE_RE.test(act.date) ? act.date : today;
  const start = new Date(startISO + "T00:00:00");

  const untilISO = act.recurrence_until && DATE_RE.test(act.recurrence_until) ? act.recurrence_until : null;
  const defaultHorizonDays =
    recurrence === "daily" ? 60 :
    recurrence === "weekly" ? 8 * 7 :
    recurrence === "biweekly" ? 12 * 14 :
    recurrence === "monthly" || recurrence === "monthly_by_weekday" ? 365 : 1;
  const end = untilISO
    ? new Date(untilISO + "T00:00:00")
    : new Date(start.getTime() + defaultHorizonDays * 86400000);

  const out: string[] = [];
  if (recurrence === "once") {
    if (DATE_RE.test(startISO)) out.push(startISO);
    return out;
  }

  if (recurrence === "monthly_by_weekday") {
    const wd = weekdays[0] ? WEEKDAYS.indexOf(weekdays[0]) : start.getDay();
    const position = act.month_position ?? "first";
    const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
    while (cursor <= end && out.length < MAX_OCCURRENCES) {
      const d = nthWeekdayOfMonth(cursor.getFullYear(), cursor.getMonth(), wd, position);
      if (d && d >= start && d <= end) out.push(isoOf(d));
      cursor.setMonth(cursor.getMonth() + 1);
    }
    return out;
  }

  if (recurrence === "monthly") {
    const d = new Date(start);
    while (d <= end && out.length < MAX_OCCURRENCES) {
      if (!exceptions.has(d.getDay())) out.push(isoOf(d));
      d.setMonth(d.getMonth() + 1);
    }
    return out;
  }

  const step = recurrence === "biweekly" ? 14 : 1;
  const targets =
    recurrence === "weekly"
      ? new Set(weekdays.map((w) => WEEKDAYS.indexOf(w)))
      : recurrence === "daily"
        ? new Set(weekdays.length ? weekdays.map((w) => WEEKDAYS.indexOf(w)) : [0, 1, 2, 3, 4, 5, 6])
        : null;

  for (let d = new Date(start); d <= end && out.length < MAX_OCCURRENCES; d.setDate(d.getDate() + step)) {
    const dow = d.getDay();
    if (exceptions.has(dow)) continue;
    if (targets && !targets.has(dow)) continue;
    out.push(isoOf(d));
  }
  return out;
}

function findMatches(
  events: EventRow[],
  q: { title_keyword?: string | null; date?: string | null; date_from?: string | null; date_to?: string | null },
): EventRow[] {
  const kw = q.title_keyword ? normalize(q.title_keyword) : "";
  return events.filter((ev) => {
    if (kw && !normalize(ev.title).includes(kw)) return false;
    if (q.date && ev.event_date !== q.date) return false;
    if (q.date_from && ev.event_date < q.date_from) return false;
    if (q.date_to && ev.event_date > q.date_to) return false;
    return true;
  });
}

function toMinutes(t?: string | null): number | null {
  if (!t) return null;
  const m = /^(\d{1,2}):(\d{2})/.exec(t);
  if (!m) return null;
  return parseInt(m[1]) * 60 + parseInt(m[2]);
}

function timesOverlap(aStart: string | null, aEnd: string | null, bStart: string | null, bEnd: string | null): boolean {
  // Sem horário em ambos → ignora (eventos all-day no mesmo dia não bloqueiam)
  const a1 = toMinutes(aStart);
  const b1 = toMinutes(bStart);
  if (a1 === null || b1 === null) return false;
  const a2 = toMinutes(aEnd) ?? a1 + 60;
  const b2 = toMinutes(bEnd) ?? b1 + 60;
  return a1 < b2 && b1 < a2;
}

type Conflict = {
  date: string;
  proposed: { title: string; time: string | null; end_time: string | null };
  existing: EventRow;
};

function detectConflicts(
  events: EventRow[],
  act: CreateAct,
  dates: string[],
  time: string | null,
  endTime: string | null,
  title: string,
  ignoreIds: Set<string>,
): Conflict[] {
  if (!time) return []; // sem horário, sem conflito
  const conflicts: Conflict[] = [];
  for (const d of dates) {
    for (const ev of events) {
      if (ev.event_date !== d) continue;
      if (ignoreIds.has(ev.id)) continue;
      if (timesOverlap(time, endTime, ev.event_time, ev.event_end_time)) {
        conflicts.push({
          date: d,
          proposed: { title, time, end_time: endTime },
          existing: ev,
        });
        if (conflicts.length >= 10) return conflicts;
      }
    }
  }
  return conflicts;
}

function listWeekdaysPt(weekdays: Weekday[], short = false): string {
  if (weekdays.length === 0) return "";
  const map = short ? WEEKDAY_PT_SHORT : WEEKDAY_PT_LONG;
  const names = weekdays.map((w) => map[w]);
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} e ${names[1]}`;
  return `${names.slice(0, -1).join(", ")} e ${names[names.length - 1]}`;
}

function describeCreate(act: CreateAct, dateCount: number): string {
  const title = (act.title ?? "Compromisso").trim() || "Compromisso";
  const t = normalizeTime(act.time);
  const et = normalizeTime(act.end_time);
  const timeStr = t ? (et ? ` das ${t} às ${et}` : ` às ${t}`) : "";

  const recurrence = act.recurrence ?? "once";
  const weekdays = (act.weekdays ?? []) as Weekday[];
  const exceptions = (act.exceptions ?? []) as Weekday[];
  const until = act.recurrence_until && DATE_RE.test(act.recurrence_until) ? ` até ${fmtDateBR(act.recurrence_until)}` : "";

  let when = "";
  if (recurrence === "once") {
    when = act.date && DATE_RE.test(act.date) ? ` em ${fmtDateBR(act.date)}` : "";
  } else if (recurrence === "daily") {
    when = weekdays.length > 0 && weekdays.length < 7
      ? `, ${listWeekdaysPt(weekdays)}`
      : ", todos os dias";
  } else if (recurrence === "weekly") {
    when = weekdays.length ? `, toda ${listWeekdaysPt(weekdays)}` : ", semanalmente";
  } else if (recurrence === "biweekly") {
    when = ", quinzenalmente";
  } else if (recurrence === "monthly") {
    when = ", mensalmente";
  } else if (recurrence === "monthly_by_weekday") {
    const pos = { first: "primeira", second: "segunda", third: "terceira", fourth: "quarta", last: "última" }[act.month_position ?? "first"];
    when = ` na ${pos} ${weekdays[0] ? WEEKDAY_PT_LONG[weekdays[0]] : "ocorrência"} de cada mês`;
  }

  const except = exceptions.length ? ` (exceto ${listWeekdaysPt(exceptions)})` : "";
  const count = dateCount > 1 ? ` — ${dateCount} ocorrência(s)` : "";

  return `**${title}**${timeStr}${when}${except}${until}${count}`;
}

function describeDelete(act: z.infer<typeof DeleteAction>): string {
  const kw = act.title_keyword ? `**${act.title_keyword}**` : "compromissos";
  if (act.date) return `Remover ${kw} de ${fmtDateBR(act.date)}`;
  if (act.date_from && act.date_to) return `Remover ${kw} entre ${fmtDateBR(act.date_from)} e ${fmtDateBR(act.date_to)}`;
  return `Remover ${kw}`;
}

function buildFriendlyMessage(
  actions: Action[],
  dateCounts: Map<number, number>,
  defaultsUsed: string[],
): string {
  const parts: string[] = [];
  const creates = actions.map((a, i) => ({ a, i })).filter((x) => x.a.type === "create");
  const deletes = actions.map((a, i) => ({ a, i })).filter((x) => x.a.type === "delete");

  if (deletes.length && creates.length) {
    parts.push("Entendi que você quer **remarcar**:");
    for (const { a } of deletes) parts.push(`- 🗑 ${describeDelete(a as z.infer<typeof DeleteAction>)}`);
    for (const { a, i } of creates) parts.push(`- ✓ Criar ${describeCreate(a as CreateAct, dateCounts.get(i) ?? 1)}`);
  } else if (creates.length) {
    if (creates.length === 1) {
      const { a, i } = creates[0];
      parts.push(`Entendi: criar ${describeCreate(a as CreateAct, dateCounts.get(i) ?? 1)}.`);
    } else {
      parts.push("Entendi: criar:");
      for (const { a, i } of creates) parts.push(`- ${describeCreate(a as CreateAct, dateCounts.get(i) ?? 1)}`);
    }
  } else if (deletes.length) {
    parts.push("Entendi:");
    for (const { a } of deletes) parts.push(`- ${describeDelete(a as z.infer<typeof DeleteAction>)}`);
  }

  if (defaultsUsed.length) {
    parts.push(`\n⚠️ *Usei padrões: ${defaultsUsed.join(", ")}*`);
  }

  parts.push("\nConfirmar?");
  return parts.join("\n");
}

async function runActions(
  actions: Action[],
  context: { supabase: any; userId: string },
  eventsList: EventRow[],
) {
  const createdRows: EventRow[] = [];
  const deletedRows: EventRow[] = [];
  const today = isoOf(new Date());

  for (const act of actions) {
    if (act.type === "delete") {
      const matches = findMatches(eventsList.filter((e) => e.event_date >= today), {
        title_keyword: act.title_keyword,
        date: act.date,
        date_from: act.date_from,
        date_to: act.date_to,
      });
      if (matches.length > 0) {
        const ids = matches.map((m) => m.id);
        const { error } = await context.supabase.from("events").delete().in("id", ids);
        if (error) throw new Error(error.message);
        deletedRows.push(...matches);
        for (const m of matches) {
          const idx = eventsList.findIndex((e) => e.id === m.id);
          if (idx >= 0) eventsList.splice(idx, 1);
        }
      }
      continue;
    }

    if (act.type === "query") continue;

    const title = (act.title ?? "").trim() || "Compromisso";
    const description = (act.description ?? "").trim() || null;
    const time = normalizeTime(act.time);
    const endTime = normalizeTime(act.end_time);
    const dates = expandRecurrence(act, today);
    if (dates.length === 0) continue;

    const rows = dates.map((d) =>
      EventInput.parse({ title, description, event_date: d, event_time: time, event_end_time: endTime }),
    );
    const { data: inserted, error } = await context.supabase
      .from("events")
      .insert(rows.map((r) => ({ ...r, user_id: context.userId })))
      .select();
    if (error) throw new Error(error.message);
    createdRows.push(...((inserted as EventRow[]) ?? []));
  }

  return { createdRows, deletedRows };
}

function groupBy(list: EventRow[]) {
  const m = new Map<string, EventRow[]>();
  for (const row of list) {
    const arr = m.get(row.title) ?? [];
    arr.push(row);
    m.set(row.title, arr);
  }
  return Array.from(m.entries()).map(([title, items]) => ({
    title,
    count: items.length,
    first_date: items[0].event_date,
    last_date: items[items.length - 1].event_date,
    time: items[0].event_time,
    end_time: items[0].event_end_time,
  }));
}

// ====== parseMessage ======

export const parseMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ text: z.string().min(1).max(2000) }).parse(input))
  .handler(async ({ data, context }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const now = new Date();
    const today = isoOf(now);
    const todayWeekday = WEEKDAYS[now.getDay()];
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const yearEnd = `${now.getFullYear()}-12-31`;
    const in7 = isoOf(new Date(now.getTime() + 7 * 86400000));
    const in14 = isoOf(new Date(now.getTime() + 14 * 86400000));
    const in30 = isoOf(new Date(now.getTime() + 30 * 86400000));
    const monthStart = isoOf(new Date(now.getFullYear(), now.getMonth(), 1));
    const monthEnd = isoOf(new Date(now.getFullYear(), now.getMonth() + 1, 0));

    const gateway = createLovableAiGatewayProvider(key);

    const { data: existing = [] } = await context.supabase
      .from("events")
      .select("id,title,description,event_date,event_time,event_end_time")
      .gte("event_date", today)
      .order("event_date", { ascending: true });

    const eventsList = (existing as EventRow[]) ?? [];
    const eventsForPrompt = eventsList.slice(0, 80)
      .map((e) => {
        const time = e.event_time ? ` ${e.event_time.slice(0, 5)}` : "";
        const endTime = e.event_end_time ? `-${e.event_end_time.slice(0, 5)}` : "";
        return `- ${e.event_date}${time}${endTime} ${e.title}`;
      })
      .join("\n") || "(nenhum)";

    const prompt = `Você é a SmartAgenda, assistente de agenda em português brasileiro, com inteligência tipo Google Calendar.

CONTEXTO TEMPORAL
- Hoje: ${today} (${WEEKDAY_PT_LONG[todayWeekday]})
- Hora atual: ${currentTime}
- Daqui a 7 dias: ${in7}
- Daqui a 14 dias: ${in14}
- Daqui a 30 dias: ${in30}
- Início do mês atual: ${monthStart}
- Fim do mês atual: ${monthEnd}
- Fim do ano atual: ${yearEnd}

COMPROMISSOS ATUAIS (para deletar/remarcar/consultar)
${eventsForPrompt}

MENSAGEM DO USUÁRIO
"""${data.text}"""

PROCESSO:
1. Identifique INTENÇÃO: "create" | "delete" | "reschedule" | "query" | "clarify"
2. Extraia título, datas, horários (início e fim), recorrência, exceções, posição no mês
3. Resolva datas/horas relativas com precisão
4. CONFIANÇA (0.0-1.0):
   - 0.9+ se tudo está claro
   - 0.6-0.85 se usou defaults ou houve pequena ambiguidade
   - <0.5 → intent="clarify" e preencha "clarification"
5. Se faltar data E hora → intent="clarify"
6. Se faltar só hora E for "create" pontual → use hora atual ${currentTime} como sugestão, mas mantenha confidence 0.6-0.7 e registre em defaults_used
7. Se faltar só data → use hoje ${today} como sugestão, registre em defaults_used

INTERPRETAÇÃO DE DATAS RELATIVAS (regra):
- "hoje" → ${today}
- "amanhã" → ${isoOf(new Date(now.getTime() + 86400000))}
- "depois de amanhã" → ${isoOf(new Date(now.getTime() + 2 * 86400000))}
- "próxima/próximo X" → o próximo X depois de hoje (não hoje mesmo, mesmo se hoje for X)
- "esta semana" → date_from=${today} date_to=${isoOf(new Date(now.getTime() + (6 - now.getDay()) * 86400000))}
- "este mês" → date_from=${monthStart} date_to=${monthEnd}
- "daqui a N dias/semanas" → some N
- "até o final do ano" → recurrence_until="${yearEnd}"
- "até o final do mês" → recurrence_until="${monthEnd}"

RECORRÊNCIAS:
- "todo dia" → recurrence="daily" weekdays=[]
- "todo dia útil"/"segunda a sexta" → recurrence="daily" weekdays=["monday","tuesday","wednesday","thursday","friday"]
- "toda terça" → recurrence="weekly" weekdays=["tuesday"]
- "toda segunda e quarta" → recurrence="weekly" weekdays=["monday","wednesday"]
- "quinzenalmente"/"a cada 15 dias" → recurrence="biweekly"
- "todo mês" → recurrence="monthly"
- "último sábado do mês" → recurrence="monthly_by_weekday" weekdays=["saturday"] month_position="last"
- "primeira segunda do mês" → recurrence="monthly_by_weekday" weekdays=["monday"] month_position="first"
- "exceto/menos terça" → exceptions=["tuesday"]
- "das 19h às 22h" → time="19:00" end_time="22:00"

FORMATO DE RESPOSTA (APENAS JSON):
{
  "intent": "create|delete|reschedule|query|clarify",
  "confidence": 0.0,
  "reasoning": "explicação interna (não será mostrada)",
  "clarification": "pergunta ao usuário se intent=clarify",
  "defaults_used": ["data: hoje (${today})", "hora: ${currentTime}"],
  "actions": [...]
}

AÇÕES:
- create: {"type":"create","title":"...","description":"","date":"YYYY-MM-DD ou ''","time":"HH:MM ou ''","end_time":"HH:MM ou ''","recurrence":"once|daily|weekly|biweekly|monthly|monthly_by_weekday","weekdays":[],"recurrence_until":"YYYY-MM-DD ou ''","exceptions":[],"month_position":"first|second|third|fourth|last ou null"}
- delete: {"type":"delete","title_keyword":"...","date":"YYYY-MM-DD","date_from":"","date_to":""}
- query: {"type":"query","date":"YYYY-MM-DD","date_from":"","date_to":"","title_keyword":""}

Para RESCHEDULE: emita delete (antigo) + create (novo).

EXEMPLOS:

1) "Tenho aula toda semana até o final do ano das 19h às 22h de segunda a sexta menos terças"
{"intent":"create","confidence":0.95,"reasoning":"recorrência diária útil exceto terça","defaults_used":[],"actions":[{"type":"create","title":"Aula","date":"${today}","time":"19:00","end_time":"22:00","recurrence":"daily","weekdays":["monday","tuesday","wednesday","thursday","friday"],"recurrence_until":"${yearEnd}","exceptions":["tuesday"]}]}

2) "Quais compromissos tenho esta semana?"
{"intent":"query","confidence":0.95,"reasoning":"consulta semanal","actions":[{"type":"query","date_from":"${today}","date_to":"${in7}"}]}

3) "Tenho médico semana que vem"
{"intent":"clarify","confidence":0.4,"reasoning":"falta dia e hora","clarification":"Qual dia da semana que vem e em que horário?","actions":[]}

4) "Tenho dentista amanhã"
{"intent":"create","confidence":0.7,"reasoning":"data clara, hora ausente","defaults_used":["hora: ${currentTime}"],"actions":[{"type":"create","title":"Dentista","date":"${isoOf(new Date(now.getTime() + 86400000))}","time":"${currentTime}","end_time":"","recurrence":"once","weekdays":[],"recurrence_until":"","exceptions":[]}]}

5) "Toda segunda e quarta às 19h reunião"
{"intent":"create","confidence":0.9,"reasoning":"recorrência semanal","defaults_used":[],"actions":[{"type":"create","title":"Reunião","date":"${today}","time":"19:00","end_time":"","recurrence":"weekly","weekdays":["monday","wednesday"],"recurrence_until":"","exceptions":[]}]}

6) "Último sábado do mês tenho clube"
{"intent":"create","confidence":0.85,"reasoning":"recorrência último sábado mensal","defaults_used":["hora: ${currentTime}"],"actions":[{"type":"create","title":"Clube","date":"${today}","time":"${currentTime}","end_time":"","recurrence":"monthly_by_weekday","weekdays":["saturday"],"month_position":"last"}]}

7) "O que tenho hoje?"
{"intent":"query","confidence":0.95,"reasoning":"consulta diária","actions":[{"type":"query","date":"${today}"}]}

8) "Cancela minha aula de segunda"
{"intent":"delete","confidence":0.85,"reasoning":"buscar aula próxima segunda","actions":[{"type":"delete","title_keyword":"aula","date":"<próxima segunda em ISO>"}]}

9) "Adia minha reunião de amanhã para sexta às 14h"
{"intent":"reschedule","confidence":0.9,"reasoning":"delete amanhã + create sexta","actions":[{"type":"delete","title_keyword":"reunião","date":"<amanhã>"},{"type":"create","title":"Reunião","date":"<próxima sexta>","time":"14:00","end_time":"","recurrence":"once"}]}

Responda APENAS JSON, sem markdown, sem comentários.`;

    const { text: aiText } = await generateText({
      model: gateway("google/gemini-3-flash-preview"),
      prompt,
    });

    const cleaned = aiText.replace(/```json\s*|```\s*/g, "").trim();
    let parsed: ParseResult;
    try {
      const raw = JSON.parse(cleaned);
      parsed = ParseResult.parse(raw);
    } catch {
      return {
        intent: "clarify" as const,
        confidence: 0,
        needs_confirmation: false,
        message: "Não consegui entender. Pode reformular?",
        clarification: "Pode reformular o que você quer agendar?",
        defaults_used: [],
        pending_actions: [],
        conflicts: [],
        executed: false,
        created: [],
        deleted: [],
        query_results: [],
      };
    }

    const actions = parsed.actions ?? [];
    const intent = parsed.intent ?? "clarify";
    const confidence = parsed.confidence ?? 0;
    const defaultsUsed = parsed.defaults_used ?? [];

    // QUERY — sempre executa
    if (intent === "query") {
      const qa = actions.find((a) => a.type === "query") as z.infer<typeof QueryAction> | undefined;
      const results = qa
        ? findMatches(eventsList, {
            title_keyword: qa.title_keyword,
            date: qa.date,
            date_from: qa.date_from,
            date_to: qa.date_to,
          })
        : eventsList;
      const msg = results.length === 0
        ? "Nenhum compromisso encontrado nesse período."
        : `Encontrei **${results.length}** compromisso(s):`;
      return {
        intent, confidence,
        needs_confirmation: false,
        message: msg,
        clarification: null,
        defaults_used: defaultsUsed,
        pending_actions: [],
        conflicts: [],
        executed: true,
        created: [], deleted: [],
        query_results: results,
      };
    }

    // CLARIFY ou confiança muito baixa
    if (intent === "clarify" || confidence < 0.5 || actions.filter((a) => a.type !== "query").length === 0) {
      const q = parsed.clarification ?? "Pode dar mais detalhes (dia, horário, título)?";
      return {
        intent: "clarify" as const,
        confidence,
        needs_confirmation: false,
        message: q,
        clarification: q,
        defaults_used: defaultsUsed,
        pending_actions: [],
        conflicts: [],
        executed: false,
        created: [], deleted: [],
        query_results: [],
      };
    }

    // ------- CREATE/DELETE/RESCHEDULE: detectar conflitos e montar mensagem amigável -------
    const writeActions = actions.filter((a) => a.type !== "query");

    // IDs que serão removidos por deletes desta mesma operação (não geram conflito com creates do mesmo turno)
    const toDeleteIds = new Set<string>();
    for (const act of writeActions) {
      if (act.type === "delete") {
        const m = findMatches(eventsList.filter((e) => e.event_date >= today), {
          title_keyword: act.title_keyword,
          date: act.date,
          date_from: act.date_from,
          date_to: act.date_to,
        });
        for (const x of m) toDeleteIds.add(x.id);
      }
    }

    const conflicts: Conflict[] = [];
    const dateCounts = new Map<number, number>();
    writeActions.forEach((act, idx) => {
      if (act.type !== "create") return;
      const dates = expandRecurrence(act, today);
      dateCounts.set(idx, dates.length);
      const t = normalizeTime(act.time);
      const et = normalizeTime(act.end_time);
      const title = (act.title ?? "Compromisso").trim() || "Compromisso";
      conflicts.push(...detectConflicts(eventsList, act, dates, t, et, title, toDeleteIds));
    });

    const friendlyMsg = buildFriendlyMessage(writeActions, dateCounts, defaultsUsed);

    // Confirmação obrigatória quando: confiança média OU defaults usados OU há conflitos
    const needs_confirmation =
      conflicts.length > 0 ||
      defaultsUsed.length > 0 ||
      (confidence >= 0.5 && confidence < 0.85);

    if (needs_confirmation) {
      let message = friendlyMsg;
      if (conflicts.length > 0) {
        const lines = conflicts.slice(0, 5).map((c) => {
          const exTime = c.existing.event_time
            ? `${fmtTime(c.existing.event_time)}${c.existing.event_end_time ? "–" + fmtTime(c.existing.event_end_time) : ""}`
            : "";
          return `- ${fmtDateBR(c.date)} ${exTime} **${c.existing.title}** conflita com **${c.proposed.title}**`;
        }).join("\n");
        const extra = conflicts.length > 5 ? `\n…e mais ${conflicts.length - 5} conflitos` : "";
        message = `⚠️ **${conflicts.length} conflito(s) detectado(s):**\n${lines}${extra}\n\n${friendlyMsg}`;
      }
      return {
        intent, confidence,
        needs_confirmation: true,
        message,
        clarification: null,
        defaults_used: defaultsUsed,
        pending_actions: writeActions,
        conflicts,
        executed: false,
        created: [], deleted: [],
        query_results: [],
      };
    }

    // Confiança alta, sem conflito, sem defaults → executa
    const { createdRows, deletedRows } = await runActions(writeActions, context, [...eventsList]);
    return {
      intent, confidence,
      needs_confirmation: false,
      message: `✅ ${friendlyMsg.replace(/\n+Confirmar\?$/, "")}`,
      clarification: null,
      defaults_used: defaultsUsed,
      pending_actions: [],
      conflicts: [],
      executed: true,
      created: createdRows,
      deleted: deletedRows,
      query_results: [],
      summary: { created: groupBy(createdRows), deleted: groupBy(deletedRows) },
    };
  });

// ====== executeActions (after user confirms) ======

export const executeActions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ actions: z.array(Action) }).parse(input))
  .handler(async ({ data, context }) => {
    const today = isoOf(new Date());
    const { data: existing = [] } = await context.supabase
      .from("events")
      .select("id,title,description,event_date,event_time,event_end_time")
      .gte("event_date", today);

    const { createdRows, deletedRows } = await runActions(
      data.actions.filter((a) => a.type !== "query"),
      context,
      [...((existing as EventRow[]) ?? [])],
    );

    return {
      created: createdRows,
      deleted: deletedRows,
      summary: { created: groupBy(createdRows), deleted: groupBy(deletedRows) },
    };
  });
