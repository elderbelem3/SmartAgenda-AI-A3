# Plano: SmartAgenda 2.0

Transformar o chat em um assistente que entende linguagem natural complexa, com confiança/confirmação, exceções de recorrência, horários de início e fim, e consulta de compromissos.

## 1. Banco de dados (1 migração)

Adicionar `event_end_time` (TIME, opcional) na tabela `events`. Sem outras mudanças — exceções de recorrência são tratadas em tempo de expansão (pulando datas).

## 2. Backend — `src/lib/events.functions.ts`

Reescrever a IA para retornar uma estrutura rica em vez de executar direto:

```ts
type ParseResult = {
  intent: "create" | "delete" | "reschedule" | "query" | "clarify";
  confidence: number;          // 0..1
  reasoning: string;           // texto curto explicando interpretação
  needs_confirmation: boolean; // true quando 0.5 ≤ confidence < 0.8
  clarification?: string;      // pergunta quando confidence < 0.5 ou ambíguo
  defaults_used?: string[];    // ex: ["data: hoje", "hora: 19:30"]
  actions: Action[];           // create/delete prontas para executar
  query_results?: EventRow[];  // quando intent=query
  message: string;             // resposta amigável pro chat
};

type CreateAction = {
  type: "create";
  title: string;
  description?: string;
  date?: string;          // YYYY-MM-DD para evento único
  time?: string;          // HH:MM início
  end_time?: string;      // HH:MM fim
  recurrence: "once" | "weekly" | "daily" | "biweekly" | "monthly";
  weekdays?: Weekday[];   // para weekly
  recurrence_until?: string; // YYYY-MM-DD (ex: 31/12 do ano)
  exceptions?: Weekday[]; // ex: ["tuesday"] — dias a pular na expansão
};
type DeleteAction = { type: "delete"; title_keyword?: string; date?: string; date_from?: string; date_to?: string };
```

Servidor:

1. `parseMessage(text)` — chama IA, retorna `ParseResult`. Não escreve no banco.
   - Se `intent=query`, executa busca local nas datas pedidas e devolve `query_results`.
   - Se `confidence ≥ 0.8` e `needs_confirmation=false`, executa as ações imediatamente (cria/remove) e devolve resultado.
   - Caso contrário, devolve as ações pendentes pro cliente confirmar.

2. `executeActions(actions)` — server fn que recebe ações já validadas e executa (create/delete). Usada quando o usuário confirma.

3. `expandRecurrence(action, today)` — expande a recorrência respeitando `recurrence_until` e `exceptions`. Suporta:
   - `weekly` com lista de dias da semana
   - `daily` (todo dia útil → seg–sex)
   - `biweekly` (a cada 14 dias a partir da primeira ocorrência)
   - `monthly` (mesmo dia do mês até `recurrence_until`)
   - Limite de segurança: máximo 365 ocorrências.

4. Prompt da IA reformulado: descreve o processo de raciocínio (intent → título → datas → horários → recorrência → exceções → confiança), explica defaults (hora atual / data hoje) e exige que `defaults_used` seja preenchido quando aplicado. Modelo continua `google/gemini-3-flash-preview` (default, mais robusto em structured output).

5. Schema validado com `z.array(...).catch([])` / `.nullish()` para tolerância como já fizemos.

## 3. Frontend — `src/routes/_authenticated/app.tsx`

- Render do chat passa a usar `react-markdown` (já é prática padrão).
- Quando resposta vem com `needs_confirmation`, renderiza bolha do assistente com botões **Confirmar / Cancelar**. Ao confirmar, chama `executeActions` com as ações pendentes; ao cancelar, descarta.
- Quando vem `clarification`, apenas mostra a pergunta no chat (sem botões).
- Quando vem `query_results`, mostra lista compacta dos compromissos encontrados.
- Quando vem `defaults_used`, anexa um aviso ("⚠ Usei hoje 19:30 como padrão") na mensagem.
- Diálogo de edição manual ganha campo opcional "Horário fim".
- Card do dia mostra `19:00 – 22:00` quando há `event_end_time`.

## 4. Detalhes técnicos relevantes

- A migração só adiciona uma coluna nullable, sem mudança de policies.
- O parser de IA continua em `generateText` + `JSON.parse` (mais tolerante que `generateObject`).
- Pendências de confirmação ficam **em memória no cliente** (`useState`). Se a aba recarregar, o usuário simplesmente repete a frase. Sem persistência extra.
- Recorrências expandidas continuam virando linhas independentes em `events` (sem `recurrence_id`) — mantém o restante do app inalterado. Exceções são pulos na expansão; futuras alterações pontuais ainda funcionam editando/removendo linhas individuais.
- Limite de inserção: 365 linhas por mensagem para evitar abuso.

## 5. Fora de escopo (proposto)

- Agrupar recorrência num único registro (`recurrence_id`) — útil para "cancelar a série", mas exige refator maior do calendário. Posso fazer depois se você quiser.
- Notificações / lembretes.
- Histórico de conversa multi-turno persistido (cada mensagem hoje é independente; basta para o fluxo de confirmação imediato).

Quer que eu siga com esse plano?
